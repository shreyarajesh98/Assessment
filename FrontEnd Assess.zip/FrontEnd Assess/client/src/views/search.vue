<template>
  <div v-if="formView">
    <button @click="logout" class="btn btn-warning float-right ml-2 offset-10">
      LOGOUT
    </button>
    <div class="panel-heading">
      <strong> Welcome to Code Snippets {{ getUser.firstName }}</strong>
    </div>
    <div class="row">
      <div class="search-wrapper panel-heading col-sm-12">
        <input
          class="border border-primary"
          type="text"
          v-model="searchQuery"
          placeholder="Search"
        />
      </div>
    </div>
    <div>
      <table v-if="resources.length" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Name</th>
            <th>Code</th>
            <th>Save</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in resultQuery" :key="item">
            <td class="col-md-2">
              <b> {{ item.name }} </b>
            </td>
            <td class="col-md-8">
              {{ item.body }}
            </td>
            <td class="col-md-2">
              <button class="btn btn-primary" @click="onSave(item)">
                Save
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <div v-else>
    <p>You dont have permission to access this page </p>
    <button @click="logout" class="btn btn-warning ">
      LOGOUT
    </button>
  </div>
</template>

<script>
import "bootstrap/dist/css/bootstrap.min.css";
import { snipptes } from "@/assets/snippets.js";
import axios from "axios";
export default {
  data() {
    return {
      searchQuery: null,
      resources: snipptes,
      getUser: "",
      expires: "",
      formView: false,
    };
  },
  computed: {
    resultQuery() {
      console.log(this.resources);
      if (this.searchQuery) {
        return this.resources.filter((item) => {
          return this.searchQuery
            .toLowerCase()
            .split(" ")
            .every((v) => item.name.toLowerCase().includes(v));
        });
      } else {
        return this.resources;
      }
    },
  },
  created() {
    if (localStorage.getItem("token") === null) {
      this.$router.push("/login");
    }
    this.getUser = JSON.parse(localStorage.getItem("user"));
    this.expires = localStorage.getItem("expire");
    const nowDate = new Date();
    var dateValidation = new Date(nowDate.getTime()) <= new Date(this.expires);
    if (!dateValidation) {
      this.logout();
    }
  },
  mounted() {
    if (localStorage.getItem("token"))
      // axios.defaults.headers.common["Authorization"] =
      //   "Bearer " + localStorage.getItem("token");
      axios
        .post("http://localhost:5000/user", {
          headers: { token: localStorage.getItem("token") },
        })
        .then((res) => {
          if (res.status === 200) {
            this.formView = true;
          }
        });
  },
  methods: {
    onSave(item) {
      const formData = {
        document: JSON.stringify(item),
        emailaddress: this.getUser.emailaddress,
      };
      this.$store.dispatch("onSave", formData);
    },
    logout() {
      localStorage.clear();
      this.$router.push("/login");
    },
  },
};
</script>
<style scoped>
input {
  display: block;
  width: 350px;
  margin: 20px auto;
  padding: 10px 45px;
  background-size: 15px 15px;
  font-size: 16px;
  border: none;
  border-radius: 5px;
  box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px,
    rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
}
</style>