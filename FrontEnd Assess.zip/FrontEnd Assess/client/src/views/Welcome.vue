<template>
  <div>
    <h1>Welcome</h1>
    <div>
    <router-link to="/">
    </router-link>
    </div>
    <div>
  </div>
  </div>
</template>
<style>
</style>