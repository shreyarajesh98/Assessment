<template>
  <base-card>
    <form @submit.prevent="submitForm">
      <h3>Sign up</h3>
      <div>
        <input
          type="text"
          placeholder="First Name"
          autoComplete="off"
          v-model.trim="firstName"
          required
        />
        <br />
        <br />
        <input
          type="text"
          placeholder="Email address"
          autoComplete="off"
          v-model.trim="emailaddress"
          required
        />
        <br />
        <br />
        <input
          type="text"
          placeholder="Password"
          autoComplete="off"
          v-model.trim="password"
          required
        />
        <br />
      </div>
      <button type="submit" class="btn btn-primary">Register</button>
    </form>
  </base-card>
</template>

<script>
export default {
  data() {
    return {
      firstName: "",
      emailaddress: "",
      password: "",
    };
  },
  methods: {
    submitForm() {
      const formData = {
        firstName: this.firstName,
        emailaddress: this.emailaddress,
        password: this.password,
      };
      this.$store.dispatch("register", formData);
      this.$router.push("/login");
    },
  },
};
</script>