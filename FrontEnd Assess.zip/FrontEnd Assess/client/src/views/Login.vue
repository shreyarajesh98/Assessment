<template>
  <base-card>
    <form @submit.prevent="submitForm">
      <h3>Sign in</h3>
      <div>
        <input
          type="text"
          placeholder="Email address"
          autoComplete="off"
          v-model.trim="emailaddress"
          required
        />
        <br />
        <br />
        <input
          type="text"
          placeholder="Password"
          autoComplete="off"
          v-model.trim="password"
          required
        />
        <br />
      </div>
      {{ error }}
      <button type="submit" class="btn btn-primary">Login</button>
      <div>
        <p>Dont have an account ? <a href="/register"> Sign Up </a></p>
      </div>
    </form>
  </base-card>
</template>

<script>
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
export default {
  data() {
    return {
      emailaddress: "",
      password: "",
      error: "",
    };
  },
  methods: {
    submitForm() {
      const formData = {
        emailaddress: this.emailaddress,
        password: this.password,
      };
      axios.post("http://localhost:5000/login", formData).then(
        (res) => {
          if (res.status === 200) {
            localStorage.setItem("token", res.data.token);
            localStorage.setItem("user", JSON.stringify(res.data.user));
            localStorage.setItem("expire", res.data.expiresAt);
            this.$toast.success(res.data.message);
            setTimeout(() => {
              this.$router.push("/");
            }, 1000);
            this.onClear();
          }
        },
        (err) => {
          this.$toast.show(err.response.data.message, {
            type: "error",
            // all of other options may go here
          });
          // this.$toast.error(err.response.data.message);
          this.error = err.response.data.error;
          this.onClear();
        }
      );
    },
    onClear() {
      (this.emailaddress = ""), (this.password = "");
    },
  },
};
</script>
<style>
p {
  line-height: 1rem;
  margin-top: 10px;
}

.card {
  padding: 20px;
}

input[type="text"],
input[type="password"] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button:hover {
  opacity: 0.8;
}

.container {
  padding: 16px;
}
</style>