import axios from 'axios'

const user = {
  mutations: {
    createLogin(state, payload) {
      state.user = payload.user
    },
  },
  actions: {
    login({ context }, payload) {
          return new Promise((resolve, reject) => {
            const API_URL = 'http://localhost:5000/login'
            axios.post(API_URL, payload).then(response => {
              localStorage.setItem("token", response.data.token);
              localStorage.setItem("user", JSON.stringify(response.data.user));
              console.log(context)
            context.dispatch('handleSuccess', response.data.message)
          resolve(response.data)
        }).catch(error => {
          reject(error)
        })
      })
    },
    register({ dispatch } , payload) {
          return new Promise((resolve, reject) => {
            const API_URL = 'http://localhost:5000/register'
            axios.post(API_URL, payload).then(response => {
              this.$toast.success(response.data.message)
            dispatch('handleSuccess', response.data.message)
          resolve(response.data)
            }).catch(error => {
              this.$toast.error(error)
          dispatch('handleError', error)
          reject(error)
        })
      })
    },
    onSave({ dispatch }, payload) {
      return new Promise((resolve, reject) => {
            const API_URL = 'http://localhost:5000/update'
        axios.post(API_URL, payload).then(response => {
            this.$toast.success(response.data.message)
            dispatch('handleSuccess', response.data.message)
          resolve(response.data)
        }).catch(error => {
              this.$toast.error(error)
          dispatch('handleError', error)
          reject(error)
        })
      })
    }
  },
  getters: {
    users: state => state.users,
  }
}

export default user