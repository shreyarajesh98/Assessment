import { createRouter, createWebHistory } from 'vue-router';


// import WelcomePage from './views/Welcome.vue';
import LoginUsers from './views/Login.vue';
import RegisterUser from './views/Register.vue';
import search from './views/search.vue';


const router = new createRouter({
  history: createWebHistory() ,
  routes: [
    { path: '/', component: search },
    { path: '/login', component: LoginUsers },
    { path: '/register', component: RegisterUser },
    // {path: '/search', component : search}
  ]
});

// router.beforeEach(function(to, _, next) {
//   if (to.meta.requiresAuth && !store.getters.isAuthenticated) {
//     next('/auth');
//   } else if (to.meta.requiresUnauth && store.getters.isAuthenticated) {
//     next('/coaches');
//   } else {
//     next();
//   }
// });
// router.beforeEach((to, from, next) => {
//   const token = localStorage.getItem("token")
//   const user = JSON.parse(localStorage.getItem("user"))
//   if (to.meta.secure) {
//     if (token) {
//       store.commit('createLogin', {
//         token,
//         user,
//       })
//       next('/')
//     } else {
//       next('/')
//     }
//   } else {
//     next()
//   }
// })

export default router;
